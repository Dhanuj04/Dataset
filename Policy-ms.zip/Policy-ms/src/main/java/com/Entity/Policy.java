package com.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Policy {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String description;
    private double standardPremium;
    private int coveragePeriod; // In months, years, etc.
    private int term;
    private long admin_id;
    private long insurance_id;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getStandardPremium() {
		return standardPremium;
	}
	public void setStandardPremium(double standardPremium) {
		this.standardPremium = standardPremium;
	}
	public int getCoveragePeriod() {
		return coveragePeriod;
	}
	public void setCoveragePeriod(int coveragePeriod) {
		this.coveragePeriod = coveragePeriod;
	}
	public int getTerm() {
		return term;
	}
	public void setTerm(int term) {
		this.term = term;
	}
	public long getAdmin_id() {
		return admin_id;
	}
	public void setAdmin_id(long admin_id) {
		this.admin_id = admin_id;
	}
	public long getInsurance_id() {
		return insurance_id;
	}
	public void setInsurance_id(long insurance_id) {
		this.insurance_id = insurance_id;
	}
	public Policy(Long id, String name, String description, double standardPremium, int coveragePeriod, int term,
			long admin_id, long insurance_id) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.standardPremium = standardPremium;
		this.coveragePeriod = coveragePeriod;
		this.term = term;
		this.admin_id = admin_id;
		this.insurance_id = insurance_id;
	}
	public Policy() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

    // Constructors, getters, setters, and other properties
}