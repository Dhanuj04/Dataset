package com.Policy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.Repository")
public class PolicyMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PolicyMsApplication.class, args);
	}

}
