package com.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Entity.Policy;
import com.Exception.PolicyNotFoundException;
import com.Repository.PolicyRepository;

@Service
public class PolicyService {
    @Autowired
    private PolicyRepository policyRepository;

    public List<Policy> getAllPolicies() {
        return policyRepository.findAll();
    }

    public Policy getPolicyById(Long policyId) {
        return policyRepository.findById(policyId)
            .orElseThrow(() -> new PolicyNotFoundException("Policy not found with ID: " + policyId));
    }

}

