package com.example.Policyms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolicyMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
